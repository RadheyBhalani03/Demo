import { prisma } from '@/lib/prisma';
import { BadRequestError, ConflictError, ForbiddenError, NotFoundError } from '@/lib/errors';
import { ProfileService } from '@/modules/profile/profile.service';
import type { AuthUser } from '@/lib/auth';

const summaryInclude = {
  student: { select: { id: true, name: true, avatarUrl: true } },
  mentor: { select: { id: true, name: true, avatarUrl: true } },
  messages: { orderBy: { createdAt: 'desc' as const }, take: 1 },
};
const detailInclude = {
  student: { select: { id: true, name: true, avatarUrl: true } },
  mentor: { select: { id: true, name: true, avatarUrl: true } },
  messages: { orderBy: { createdAt: 'asc' as const }, take: 200 },
};

async function currentDbUser(auth: AuthUser) {
  const profile = await ProfileService.getProfileByUserIdOrEmail(auth.id, auth.email);
  if (!profile) throw new NotFoundError('Create your Bridges profile before messaging.');
  const user = await prisma.user.findUnique({ where: { id: Number(profile.id) } });
  if (!user || user.isSuspended) throw new ForbiddenError('Your account cannot send messages.');
  return user;
}

function mappedConversation(
  conversation: {
    id: number;
    studentId: number;
    mentorId: number;
    status: string;
    updatedAt: Date;
    student: { id: number; name: string; avatarUrl: string | null };
    mentor: { id: number; name: string; avatarUrl: string | null };
    messages: { id: number; senderId: number; text: string; createdAt: Date }[];
  },
  myId: number
) {
  const otherUser = myId === conversation.studentId ? conversation.mentor : conversation.student;
  return {
    id: String(conversation.id),
    studentId: String(conversation.studentId),
    mentorId: String(conversation.mentorId),
    status: conversation.status,
    otherUser: { id: String(otherUser.id), name: otherUser.name, avatarUrl: otherUser.avatarUrl },
    updatedAt: conversation.updatedAt.toISOString(),
    messages: conversation.messages.map(m => ({
      id: String(m.id), senderId: String(m.senderId), text: m.text, createdAt: m.createdAt.toISOString(),
    })),
  };
}

export const ChatService = {
  async list(auth: AuthUser) {
    const user = await currentDbUser(auth);
    const conversations = await prisma.chatConversation.findMany({
      where: { OR: [{ mentorId: user.id }, { studentId: user.id }] },
      include: summaryInclude,
      orderBy: { updatedAt: 'desc' },
      take: 100,
    });
    return conversations.map(c => mappedConversation(c, user.id));
  },

  async byId(auth: AuthUser, conversationId: number) {
    const user = await currentDbUser(auth);
    const chat = await prisma.chatConversation.findFirst({
      where: { id: conversationId, OR: [{ studentId: user.id }, { mentorId: user.id }] },
      include: detailInclude,
    });
    if (!chat) throw new NotFoundError('Conversation not found.');
    return mappedConversation(chat, user.id);
  },

  async withMentor(auth: AuthUser, mentorId: number) {
    const user = await currentDbUser(auth);
    if (user.role !== 'STUDENT') throw new ForbiddenError('Only students can start mentor requests.');
    const chat = await prisma.chatConversation.findUnique({
      where: { studentId_mentorId: { studentId: user.id, mentorId } },
      include: detailInclude,
    });
    return chat ? mappedConversation(chat, user.id) : null;
  },

  async start(auth: AuthUser, mentorId: number, text: string) {
    const student = await currentDbUser(auth);
    if (student.role !== 'STUDENT') throw new ForbiddenError('Only students can start mentor requests.');
    const mentor = await prisma.user.findFirst({
      where: { id: mentorId, role: 'MENTOR', isSuspended: false }, select: { id: true },
    });
    if (!mentor) throw new NotFoundError('Mentor not found.');
    if (student.id === mentor.id) throw new BadRequestError('Cannot contact yourself.');
    try {
      const chat = await prisma.chatConversation.create({
        data: {
          studentId: student.id,
          mentorId: mentor.id,
          status: 'PENDING',
          messages: { create: { senderId: student.id, text } },
        },
        include: detailInclude,
      });
      return mappedConversation(chat, student.id);
    } catch (error: unknown) {
      if (typeof error === 'object' && error !== null && 'code' in error && error.code === 'P2002') {
        throw new ConflictError('You already contacted this mentor. Open your existing conversation.');
      }
      throw error;
    }
  },

  async send(auth: AuthUser, conversationId: number, text: string) {
    const user = await currentDbUser(auth);
    await prisma.$transaction(async tx => {
      const chat = await tx.chatConversation.findFirst({
        where: { id: conversationId, OR: [{ studentId: user.id }, { mentorId: user.id }] },
      });
      if (!chat) throw new NotFoundError('Conversation not found.');
      if (chat.studentId === user.id && chat.status === 'PENDING') {
        throw new ForbiddenError('Wait for your mentor to reply before sending another message.');
      }
      // Mentor's first reply is what unlocks the conversation for the student.
      if (chat.mentorId === user.id && chat.status === 'PENDING') {
        await tx.chatConversation.update({ where: { id: chat.id }, data: { status: 'ACTIVE' } });
      }
      await tx.chatMessage.create({ data: { conversationId: chat.id, senderId: user.id, text } });
      await tx.chatConversation.update({ where: { id: chat.id }, data: { updatedAt: new Date() } });
    });
    return this.byId(auth, conversationId);
  },
};
