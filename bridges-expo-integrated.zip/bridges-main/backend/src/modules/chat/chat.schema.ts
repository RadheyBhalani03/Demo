import { z } from 'zod';
export const startChatSchema = z.object({
  mentorId: z.coerce.number().int().positive(),
  text: z.string().trim().min(1).max(1500),
});
export const chatMessageSchema = z.object({
  text: z.string().trim().min(1).max(1500),
});
export function parseChatId(value: string) {
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id <= 0) throw new Error('Invalid conversation ID.');
  return id;
}
