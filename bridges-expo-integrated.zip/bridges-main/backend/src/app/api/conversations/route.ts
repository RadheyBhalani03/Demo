import { NextRequest } from 'next/server';
import { withAuth } from '@/lib/auth';
import { sendResponse } from '@/lib/sendResponse';
import { parseJsonBody } from '@/lib/validate';
import { startChatSchema } from '@/modules/chat/chat.schema';
import { ChatService } from '@/modules/chat/chat.service';

export const dynamic = 'force-dynamic';
export const GET = withAuth(async (_req, { user }) => {
  return sendResponse(200, await ChatService.list(user), 'Conversations loaded.');
});
export const POST = withAuth(async (req: NextRequest, { user }) => {
  const { mentorId, text } = await parseJsonBody(req, startChatSchema);
  return sendResponse(201, await ChatService.start(user, mentorId, text), 'Request sent to mentor.');
});
