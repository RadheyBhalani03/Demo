import { withAuth } from '@/lib/auth';
import { sendResponse } from '@/lib/sendResponse';
import { BadRequestError } from '@/lib/errors';
import { ChatService } from '@/modules/chat/chat.service';
export const dynamic = 'force-dynamic';
export const GET = withAuth<{ id: string }>(async (_req, { user, params }) => {
  const id = Number((await params).id);
  if (!Number.isSafeInteger(id) || id <= 0) throw new BadRequestError('Invalid conversation ID.');
  return sendResponse(200, await ChatService.byId(user, id), 'Conversation loaded.');
});
