import { NextRequest } from 'next/server';
import { withAuth } from '@/lib/auth';
import { sendResponse } from '@/lib/sendResponse';
import { parseJsonBody } from '@/lib/validate';
import { BadRequestError } from '@/lib/errors';
import { chatMessageSchema } from '@/modules/chat/chat.schema';
import { ChatService } from '@/modules/chat/chat.service';
export const POST = withAuth<{ id: string }>(async (req: NextRequest, { user, params }) => {
  const id = Number((await params).id);
  if (!Number.isSafeInteger(id) || id <= 0) throw new BadRequestError('Invalid conversation ID.');
  const { text } = await parseJsonBody(req, chatMessageSchema);
  return sendResponse(200, await ChatService.send(user, id, text), 'Message sent.');
});
