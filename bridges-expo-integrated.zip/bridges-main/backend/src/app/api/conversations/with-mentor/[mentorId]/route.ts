import { withAuth } from '@/lib/auth';
import { sendResponse } from '@/lib/sendResponse';
import { BadRequestError } from '@/lib/errors';
import { ChatService } from '@/modules/chat/chat.service';
export const dynamic = 'force-dynamic';
export const GET = withAuth<{ mentorId: string }>(async (_req, { user, params }) => {
  const mentorId = Number((await params).mentorId);
  if (!Number.isSafeInteger(mentorId) || mentorId <= 0) throw new BadRequestError('Invalid mentor ID.');
  return sendResponse(200, await ChatService.withMentor(user, mentorId), 'Mentor conversation loaded.');
});
