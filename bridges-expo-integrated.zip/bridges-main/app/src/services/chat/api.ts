import { api } from '@/services/api';
import type { ApiEnvelope } from '@/services/profile/types';

export type ChatStatus = 'PENDING' | 'ACTIVE';
export interface ChatMessage {
  id: string;
  senderId: string;
  text: string;
  createdAt: string;
}
export interface Conversation {
  id: string;
  studentId: string;
  mentorId: string;
  status: ChatStatus;
  otherUser: { id: string; name: string; avatarUrl: string | null };
  updatedAt: string;
  messages: ChatMessage[];
}

export async function getConversations(): Promise<Conversation[]> {
  const response = await api.get<ApiEnvelope<Conversation[]>>('/api/conversations');
  return response.data.data ?? [];
}
export async function getConversation(id: string): Promise<Conversation> {
  const response = await api.get<ApiEnvelope<Conversation>>(`/api/conversations/${encodeURIComponent(id)}`);
  if (!response.data.data) throw new Error('Conversation not found.');
  return response.data.data;
}
export async function getConversationWithMentor(mentorId: string): Promise<Conversation | null> {
  const response = await api.get<ApiEnvelope<Conversation | null>>(
    `/api/conversations/with-mentor/${encodeURIComponent(mentorId)}`
  );
  return response.data.data ?? null;
}
export async function startConversation(mentorId: string, text: string): Promise<Conversation> {
  const response = await api.post<ApiEnvelope<Conversation>>('/api/conversations', { mentorId: Number(mentorId), text });
  if (!response.data.data) throw new Error('Unable to start conversation.');
  return response.data.data;
}
export async function sendChatMessage(id: string, text: string): Promise<Conversation> {
  const response = await api.post<ApiEnvelope<Conversation>>(
    `/api/conversations/${encodeURIComponent(id)}/messages`, { text }
  );
  if (!response.data.data) throw new Error('Unable to send message.');
  return response.data.data;
}
export function chatErrorMessage(error: unknown): string {
  if (typeof error === 'object' && error && 'response' in error) {
    const body = (error as { response?: { data?: { message?: string } } }).response?.data;
    if (body?.message) return body.message;
  }
  return error instanceof Error ? error.message : 'Please try again.';
}
