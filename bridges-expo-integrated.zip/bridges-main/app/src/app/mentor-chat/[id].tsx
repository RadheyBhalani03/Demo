import { useState } from 'react';
import { ActivityIndicator, Alert, Image, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { useMentorDetailQuery } from '@/services/mentors/queries';
import { chatErrorMessage, getConversationWithMentor, startConversation } from '@/services/chat/api';

export default function StartMentorChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const mentorId = id ?? '';
  const { data: mentor, isLoading: mentorLoading } = useMentorDetailQuery(mentorId);
  const { data: existing, isLoading: chatLoading, refetch } = useQuery({
    queryKey: ['chat', 'with-mentor', mentorId],
    queryFn: () => getConversationWithMentor(mentorId),
    enabled: Boolean(mentorId),
  });
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);

  async function submit() {
    const message = text.trim();
    if (!message || sending) return;
    setSending(true);
    try {
      const chat = await startConversation(mentorId, message);
      router.replace({ pathname: '/conversation/[id]', params: { id: chat.id } });
    } catch (error) {
      const result = await refetch();
      if (result.data) {
        router.replace({ pathname: '/conversation/[id]', params: { id: result.data.id } });
      } else {
        Alert.alert('Could not send request', chatErrorMessage(error));
      }
    } finally {
      setSending(false);
    }
  }

  if (mentorLoading || chatLoading) {
    return <SafeAreaView style={styles.center}><ActivityIndicator size="large" color="#4868F5" /></SafeAreaView>;
  }
  if (!mentor) {
    return <SafeAreaView style={styles.center}><Text>Unable to load this mentor.</Text><Pressable onPress={() => router.back()}><Text style={styles.back}>Go back</Text></Pressable></SafeAreaView>;
  }

  return (
    <SafeAreaView edges={['top', 'bottom']} style={styles.safe}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()}><Text style={styles.back}>← Back</Text></Pressable>
          <Text style={styles.heading}>{existing ? 'Your mentor connection' : 'Introduce yourself'}</Text>
          <Text style={styles.muted}>One thoughtful message is all it takes to start.</Text>
        </View>
        <View style={styles.card}>
          <View style={styles.person}>
            {mentor.avatarUrl ? <Image source={{ uri: mentor.avatarUrl }} style={styles.avatar} /> : <View style={[styles.avatar, styles.fallback]}><Text style={{ color: '#4868F5', fontSize: 26 }}>{mentor.name[0]}</Text></View>}
            <View style={{ flex: 1 }}>
              <Text style={styles.mentorName}>{mentor.name}</Text>
              <Text style={styles.muted}>{mentor.jobTitle || 'Mentor'}{mentor.company ? ` at ${mentor.company}` : ''}</Text>
            </View>
          </View>
          {existing ? (
            <>
              <Text style={styles.muted}>{existing.status === 'PENDING' ? 'Your introduction is waiting for a mentor reply.' : 'Your conversation is active.'}</Text>
              <Pressable style={styles.primary} onPress={() => router.replace({ pathname: '/conversation/[id]', params: { id: existing.id } })}>
                <Text style={styles.primaryLabel}>Open conversation →</Text>
              </Pressable>
            </>
          ) : (
            <>
              <Text style={styles.label}>Your first message</Text>
              <TextInput
                multiline
                maxLength={1500}
                textAlignVertical="top"
                style={styles.input}
                value={text}
                onChangeText={setText}
                placeholder={`Hi ${mentor.name.split(' ')[0]}, I'm interested in your experience with ${mentor.expertise[0] || 'your field'}. I would love some advice on...`}
                placeholderTextColor="#A2AABC"
              />
              <Text style={styles.small}>{text.length}/1500</Text>
              <View style={styles.notice}><Text style={styles.noticeText}>🔒 You can send one introduction. The conversation unlocks when {mentor.name.split(' ')[0]} replies.</Text></View>
              <Pressable style={[styles.primary, (!text.trim() || sending) && { opacity: 0.45 }]} disabled={!text.trim() || sending} onPress={submit}>
                <Text style={styles.primaryLabel}>{sending ? 'Sending…' : 'Send connection request →'}</Text>
              </Pressable>
            </>
          )}
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F6F7FA' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#F6F7FA' },
  header: { backgroundColor: 'white', padding: 20, gap: 7 },
  back: { color: '#4868F5', fontWeight: '700', fontSize: 14, marginBottom: 9 },
  heading: { color: '#19233A', fontSize: 24, fontWeight: '800' },
  muted: { color: '#8892A6', fontSize: 13, lineHeight: 19 },
  card: { margin: 18, backgroundColor: 'white', padding: 18, borderRadius: 18, gap: 16 },
  person: { flexDirection: 'row', alignItems: 'center', gap: 13, paddingBottom: 12, borderBottomWidth: 1, borderColor: '#F0F1F6' },
  mentorName: { color: '#19233A', fontSize: 16, fontWeight: '800' },
  avatar: { width: 56, height: 56, borderRadius: 18 },
  fallback: { backgroundColor: '#EEF2FF', justifyContent: 'center', alignItems: 'center' },
  label: { color: '#1B2541', fontSize: 14, fontWeight: '700' },
  input: { minHeight: 146, borderWidth: 1, borderColor: '#E5EAF3', borderRadius: 12, backgroundColor: '#F7F8FC', padding: 14, color: '#1B2541', fontSize: 14, lineHeight: 21 },
  small: { textAlign: 'right', color: '#A2AABC', fontSize: 11, marginTop: -9 },
  notice: { backgroundColor: '#F1F4FF', padding: 12, borderRadius: 12 },
  noticeText: { color: '#5066B2', fontSize: 12, lineHeight: 19 },
  primary: { backgroundColor: '#4868F5', padding: 15, borderRadius: 12, alignItems: 'center' },
  primaryLabel: { color: 'white', fontWeight: '800', fontSize: 14 },
});
