import { useState } from 'react';
import { ActivityIndicator, Image, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { getConversations } from '@/services/chat/api';
import { useRole } from '@/hooks/use-role';

export default function MessagesScreen() {
  const router = useRouter();
  const { isMentor } = useRole();
  const [search, setSearch] = useState('');
  const { data = [], isLoading, isError, error, refetch, isRefetching } = useQuery({
    queryKey: ['conversations'],
    queryFn: getConversations,
    refetchInterval: 10000,
  });
  const filtered = data.filter(c => c.otherUser.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <SafeAreaView edges={['top']} style={styles.safe}>
      <ScrollView
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={() => refetch()} tintColor="#4868F5" />}
      >
        <View style={styles.top}>
          <Text style={styles.title}>Messages</Text>
          <Text style={styles.subtitle}>{isMentor ? 'Respond to mentorship requests from students.' : 'Build connections with your mentors.'}</Text>
        </View>
        {!isMentor ? (
          <Pressable accessibilityRole="button" style={styles.cta} onPress={() => router.push('/connect-mentors')}>
            <Text style={styles.ctaText}>＋  Find and connect with mentors</Text>
            <Text style={styles.ctaArrow}>→</Text>
          </Pressable>
        ) : null}
        <TextInput
          placeholder="Search conversations..."
          value={search}
          onChangeText={setSearch}
          placeholderTextColor="#9AA3B5"
          style={styles.search}
        />
        {isLoading ? <ActivityIndicator size="large" color="#4868F5" style={{ marginTop: 30 }} /> : null}
        {isError ? (
          <View style={styles.emptyBox}><Text style={styles.emptyTitle}>Could not load messages</Text><Text style={styles.subtitle}>{error?.message ?? 'Please try again.'}</Text><Pressable onPress={() => refetch()}><Text style={styles.link}>Retry</Text></Pressable></View>
        ) : null}
        {!isLoading && !isError && filtered.length === 0 ? (
          <View style={styles.emptyBox}>
            <Text style={styles.emptyEmoji}>💬</Text>
            <Text style={styles.emptyTitle}>{search ? 'No matching conversations' : isMentor ? 'No student requests yet' : 'Start your first connection'}</Text>
            <Text style={styles.subtitle}>{isMentor ? 'Student introductions will appear here.' : 'Find a mentor, introduce yourself and wait for their reply.'}</Text>
          </View>
        ) : null}
        {filtered.map(chat => {
          const last = chat.messages[0];
          return (
            <Pressable
              accessibilityRole="button"
              key={chat.id}
              onPress={() => router.push({ pathname: '/conversation/[id]', params: { id: chat.id } })}
              style={styles.card}
            >
              {chat.otherUser.avatarUrl ? <Image source={{ uri: chat.otherUser.avatarUrl }} style={styles.avatar} /> : <View style={[styles.avatar, styles.fallback]}><Text style={styles.initial}>{chat.otherUser.name.slice(0, 1)}</Text></View>}
              <View style={{ flex: 1, gap: 5 }}>
                <View style={styles.nameRow}>
                  <Text style={styles.name}>{chat.otherUser.name}</Text>
                  <Text style={styles.time}>{new Date(chat.updatedAt).toLocaleDateString()}</Text>
                </View>
                <Text numberOfLines={1} style={styles.preview}>{last?.text ?? 'Start your conversation'}</Text>
                {chat.status === 'PENDING' ? <Text style={styles.pending}>{isMentor ? '● Reply to unlock chat' : '◷ Waiting for mentor reply'}</Text> : <Text style={styles.active}>✓ Connected</Text>}
              </View>
            </Pressable>
          );
        })}
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F7F8FB' },
  content: { padding: 20, gap: 13, paddingBottom: 40 },
  top: { marginBottom: 8, gap: 6 },
  title: { color: '#18233A', fontSize: 27, fontWeight: '800' },
  subtitle: { color: '#8993A6', fontSize: 13, lineHeight: 19 },
  cta: { backgroundColor: '#4868F5', borderRadius: 15, minHeight: 53, alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 17 },
  ctaText: { color: 'white', fontSize: 13, fontWeight: '800' },
  ctaArrow: { color: 'white', fontSize: 20 },
  search: { borderRadius: 13, backgroundColor: 'white', padding: 14, fontSize: 14, borderWidth: 1, borderColor: '#EBEEF4' },
  card: { backgroundColor: 'white', padding: 14, borderRadius: 16, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderColor: '#EEF0F4' },
  avatar: { width: 51, height: 51, borderRadius: 16 },
  fallback: { backgroundColor: '#ECF1FF', justifyContent: 'center', alignItems: 'center' },
  initial: { color: '#4868F5', fontWeight: '800', fontSize: 20 },
  nameRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 7 },
  name: { color: '#1A2540', fontWeight: '800', fontSize: 15, flex: 1 },
  time: { color: '#A0A9B8', fontSize: 10 },
  preview: { color: '#768097', fontSize: 13 },
  pending: { color: '#D08A29', fontSize: 11, fontWeight: '700' },
  active: { color: '#25977B', fontSize: 11, fontWeight: '700' },
  emptyBox: { marginTop: 20, padding: 28, backgroundColor: 'white', borderRadius: 16, gap: 10, alignItems: 'center' },
  emptyEmoji: { fontSize: 34 },
  emptyTitle: { fontWeight: '800', color: '#22324B', fontSize: 16, textAlign: 'center' },
  link: { color: '#4868F5', fontWeight: '800' },
});
