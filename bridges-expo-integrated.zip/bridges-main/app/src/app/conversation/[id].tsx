import { useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, Image, KeyboardAvoidingView, Platform,
  Pressable, ScrollView, StyleSheet, Text, TextInput, View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useRole } from '@/hooks/use-role';
import { chatErrorMessage, getConversation, sendChatMessage } from '@/services/chat/api';

export default function ConversationScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { profile, isMentor } = useRole();
  const queryClient = useQueryClient();
  const chatId = id ?? '';
  const { data: chat, isLoading, isError, error, refetch, isRefetching } = useQuery({
    queryKey: ['conversation', chatId],
    queryFn: () => getConversation(chatId),
    enabled: Boolean(chatId),
    refetchInterval: 5000, // Poll for the mentor's first reply and new messages.
  });
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<ScrollView>(null);
  const canSend = Boolean(chat && (isMentor || chat.status === 'ACTIVE'));

  async function send() {
    const value = draft.trim();
    if (!value || !canSend || !chat || sending) return;
    setSending(true);
    try {
      const result = await sendChatMessage(chat.id, value);
      queryClient.setQueryData(['conversation', chatId], result);
      await queryClient.invalidateQueries({ queryKey: ['conversations'] });
      setDraft('');
    } catch (e) {
      Alert.alert('Message not sent', chatErrorMessage(e));
      refetch();
    } finally {
      setSending(false);
    }
  }

  if (isLoading) {
    return <SafeAreaView style={styles.center}><ActivityIndicator size="large" color="#4868F5" /></SafeAreaView>;
  }
  if (isError || !chat) {
    return <SafeAreaView style={styles.center}><Text style={styles.error}>Unable to load conversation</Text><Text style={styles.muted}>{error?.message ?? 'Please try again'}</Text><Pressable onPress={() => refetch()}><Text style={styles.refresh}>Retry</Text></Pressable></SafeAreaView>;
  }

  const waiting = !isMentor && chat.status === 'PENDING';
  return (
    <SafeAreaView edges={['top', 'bottom']} style={styles.safe}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={0}>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} accessibilityRole="button"><Text style={styles.back}>‹</Text></Pressable>
          {chat.otherUser.avatarUrl ? (
            <Image source={{ uri: chat.otherUser.avatarUrl }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatar, styles.fallback]}><Text style={{ fontWeight: '800', color: '#4868F5' }}>{chat.otherUser.name.slice(0, 1)}</Text></View>
          )}
          <View style={{ flex: 1 }}>
            <Text style={styles.name}>{chat.otherUser.name}</Text>
            <Text style={styles.status}>{chat.status === 'PENDING' ? 'Request pending' : 'Conversation active'}</Text>
          </View>
          <Pressable accessibilityRole="button" onPress={() => refetch()} disabled={isRefetching}><Text style={styles.refresh}>{isRefetching ? '…' : '↻'}</Text></Pressable>
        </View>
        {waiting && (
          <View style={styles.pendingNotice}>
            <Text style={styles.pendingTitle}>⏳ Awaiting mentor response</Text>
            <Text style={styles.pendingText}>Your introduction has been sent. You can send more messages once the mentor replies.</Text>
          </View>
        )}
        {isMentor && chat.status === 'PENDING' && (
          <View style={styles.mentorNotice}>
            <Text style={styles.pendingTitle}>New mentorship request</Text>
            <Text style={styles.pendingText}>Your first reply unlocks the chat for the student.</Text>
          </View>
        )}
        <ScrollView
          ref={scrollRef}
          contentContainerStyle={styles.messages}
          onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: true })}
          keyboardShouldPersistTaps="handled"
        >
          {chat.messages.map(message => {
            const mine = message.senderId === profile?.id;
            return (
              <View key={message.id} style={[styles.messageWrap, mine ? styles.messageMine : styles.messageOther]}>
                <View style={[styles.bubble, mine ? styles.bubbleMine : styles.bubbleOther]}>
                  <Text style={[styles.messageText, mine && { color: 'white' }]}>{message.text}</Text>
                </View>
                <Text style={styles.timestamp}>
                  {new Date(message.createdAt).toLocaleString(undefined, { hour: 'numeric', minute: '2-digit', month: 'short', day: 'numeric' })}
                </Text>
              </View>
            );
          })}
        </ScrollView>
        <View style={styles.composer}>
          <TextInput
            multiline
            maxLength={1500}
            value={draft}
            onChangeText={setDraft}
            editable={canSend && !sending}
            placeholder={waiting ? 'Waiting for mentor reply…' : 'Write a message…'}
            placeholderTextColor="#A2AABC"
            style={[styles.input, !canSend && { backgroundColor: '#F1F2F5' }]}
            accessibilityLabel="Message"
          />
          <Pressable
            accessibilityRole="button"
            onPress={send}
            disabled={!canSend || !draft.trim() || sending}
            style={[styles.send, (!canSend || !draft.trim() || sending) && styles.sendDisabled]}
          >
            {sending ? <ActivityIndicator color="white" size="small" /> : <Text style={styles.sendLabel}>➤</Text>}
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F7F8FB' },
  center: { flex: 1, backgroundColor: '#F7F8FB', alignItems: 'center', justifyContent: 'center', padding: 20, gap: 14 },
  error: { color: '#1B2541', fontSize: 18, fontWeight: '800' },
  muted: { color: '#8892A6' },
  header: { flexDirection: 'row', backgroundColor: 'white', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 18, gap: 11, borderBottomWidth: 1, borderBottomColor: '#EBEDF4' },
  back: { color: '#4868F5', fontSize: 32, paddingRight: 5 },
  avatar: { width: 40, height: 40, borderRadius: 20 },
  fallback: { backgroundColor: '#EAF0FF', alignItems: 'center', justifyContent: 'center' },
  name: { fontSize: 16, fontWeight: '800', color: '#18223A' },
  status: { color: '#8691A6', fontSize: 11, marginTop: 3 },
  refresh: { color: '#4868F5', fontWeight: '700', fontSize: 20 },
  pendingNotice: { backgroundColor: '#FFF6E8', paddingHorizontal: 18, paddingVertical: 13, gap: 5 },
  mentorNotice: { backgroundColor: '#EBF0FF', paddingHorizontal: 18, paddingVertical: 13, gap: 5 },
  pendingTitle: { fontWeight: '800', color: '#6E532C', fontSize: 13 },
  pendingText: { color: '#896E4C', fontSize: 12, lineHeight: 17 },
  messages: { padding: 17, paddingBottom: 28, flexGrow: 1, gap: 15, justifyContent: 'flex-end' },
  messageWrap: { maxWidth: '84%', gap: 5 },
  messageMine: { alignSelf: 'flex-end', alignItems: 'flex-end' },
  messageOther: { alignSelf: 'flex-start', alignItems: 'flex-start' },
  bubble: { paddingVertical: 12, paddingHorizontal: 15, borderRadius: 16 },
  bubbleMine: { backgroundColor: '#4868F5', borderBottomRightRadius: 4 },
  bubbleOther: { backgroundColor: 'white', borderBottomLeftRadius: 4, borderWidth: 1, borderColor: '#ECEEF4' },
  messageText: { color: '#243047', fontSize: 14, lineHeight: 20 },
  timestamp: { color: '#A0A9BB', fontSize: 10, marginHorizontal: 3 },
  composer: { flexDirection: 'row', alignItems: 'flex-end', padding: 12, backgroundColor: 'white', borderTopWidth: 1, borderTopColor: '#EBEDF4', gap: 9 },
  input: { flex: 1, minHeight: 45, maxHeight: 120, paddingVertical: 11, paddingHorizontal: 14, borderWidth: 1, borderColor: '#E9ECF3', backgroundColor: '#F8F9FB', borderRadius: 13, color: '#18223A', fontSize: 14 },
  send: { width: 46, height: 46, borderRadius: 13, alignItems: 'center', justifyContent: 'center', backgroundColor: '#4868F5' },
  sendDisabled: { backgroundColor: '#B9C3E5' },
  sendLabel: { color: 'white', fontSize: 18 },
});
