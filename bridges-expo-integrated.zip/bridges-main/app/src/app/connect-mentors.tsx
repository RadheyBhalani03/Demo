import { useState } from 'react';
import {
  ActivityIndicator, Image, Pressable, ScrollView, StyleSheet, Text, TextInput, View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useMentorsQuery } from '@/services/mentors/queries';
import { useRole } from '@/hooks/use-role';
import { ROUTES } from '@/constants/routes';

export default function ConnectMentorsScreen() {
  const router = useRouter();
  const { isMentor } = useRole();
  const [search, setSearch] = useState('');
  const { data, isLoading, isError, error, refetch } = useMentorsQuery({ search: search.trim() || undefined, limit: 40 });
  return (
    <SafeAreaView edges={['top']} style={styles.safe}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} accessibilityRole="button"><Text style={styles.back}>← Back</Text></Pressable>
        <Text style={styles.title}>Connect with mentors</Text>
        <Text style={styles.subtitle}>Discover people who can guide you on your journey.</Text>
        <View style={styles.searchBox}>
          <Text style={{ fontSize: 18, color: '#8E98AB' }}>⌕</Text>
          <TextInput
            style={styles.searchInput}
            placeholder="Search by name, career or expertise..."
            placeholderTextColor="#A0A8B7"
            value={search}
            onChangeText={setSearch}
          />
        </View>
      </View>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {isMentor ? <Text style={styles.notice}>You are signed in as a mentor. New mentorship requests are started by students.</Text> : null}
        {isLoading ? <ActivityIndicator size="large" color="#4868F5" style={{ marginTop: 40 }} /> : null}
        {isError ? (
          <View style={styles.card}>
            <Text>Could not load mentors: {error?.message ?? 'Please try again.'}</Text>
            <Pressable onPress={() => refetch()} style={styles.secondaryButton}><Text style={styles.secondaryText}>Retry</Text></Pressable>
          </View>
        ) : null}
        {!isLoading && !isError && data?.items.length === 0 ? <Text style={styles.empty}>No mentors found. Try a different search.</Text> : null}
        {data?.items.map(mentor => (
          <View key={mentor.id} style={styles.card}>
            <View style={styles.mentorTop}>
              {mentor.avatarUrl ? (
                <Image source={{ uri: mentor.avatarUrl }} style={styles.avatar} />
              ) : (
                <View style={[styles.avatar, styles.fallback]}><Text style={styles.fallbackText}>{mentor.name.slice(0, 1)}</Text></View>
              )}
              <View style={{ flex: 1 }}>
                <Text style={styles.name}>{mentor.name}</Text>
                <Text style={styles.position}>{mentor.jobTitle || 'Mentor'}{mentor.company ? ` • ${mentor.company}` : ''}</Text>
                {mentor.industry ? <Text style={styles.industry}>{mentor.industry}</Text> : null}
              </View>
            </View>
            {mentor.bio ? <Text style={styles.bio} numberOfLines={3}>{mentor.bio}</Text> : null}
            <View style={styles.chips}>
              {mentor.expertise.slice(0, 3).map(skill => <View key={skill} style={styles.chip}><Text style={styles.chipText}>{skill}</Text></View>)}
            </View>
            <View style={styles.buttons}>
              <Pressable style={styles.secondaryButton} onPress={() => router.push(ROUTES.mentorDetail(mentor.id))}>
                <Text style={styles.secondaryText}>View Profile</Text>
              </Pressable>
              {!isMentor ? (
                <Pressable
                  style={styles.primaryButton}
                  onPress={() => router.push({ pathname: '/mentor-chat/[id]', params: { id: mentor.id } })}
                >
                  <Text style={styles.primaryText}>Message →</Text>
                </Pressable>
              ) : null}
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F6F7FA' },
  header: { backgroundColor: 'white', paddingHorizontal: 20, paddingTop: 18, paddingBottom: 18, gap: 6 },
  back: { color: '#4868F5', fontSize: 14, fontWeight: '700', marginBottom: 12 },
  title: { fontSize: 25, color: '#17213A', fontWeight: '800' },
  subtitle: { fontSize: 13, color: '#8791A5' },
  searchBox: { backgroundColor: '#F5F6FA', borderRadius: 14, flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 15, paddingHorizontal: 14 },
  searchInput: { paddingVertical: 13, flex: 1, color: '#142039', fontSize: 13 },
  content: { padding: 18, paddingBottom: 30, gap: 14 },
  card: { padding: 16, backgroundColor: 'white', borderRadius: 17, borderWidth: 1, borderColor: '#EDF0F6', gap: 13 },
  mentorTop: { flexDirection: 'row', gap: 13, alignItems: 'center' },
  avatar: { height: 58, width: 58, borderRadius: 16 },
  fallback: { alignItems: 'center', justifyContent: 'center', backgroundColor: '#EAF0FF' },
  fallbackText: { color: '#4868F5', fontWeight: '800', fontSize: 24 },
  name: { fontSize: 16, fontWeight: '800', color: '#19233A' },
  position: { fontSize: 12, color: '#69758B', marginTop: 4 },
  industry: { fontSize: 11, color: '#8791A5', marginTop: 4 },
  bio: { fontSize: 13, color: '#6C7589', lineHeight: 20 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  chip: { borderWidth: 1, borderColor: '#DBE2FD', borderRadius: 20, paddingVertical: 5, paddingHorizontal: 8, backgroundColor: '#F2F5FF' },
  chipText: { fontSize: 11, color: '#4868F5' },
  buttons: { flexDirection: 'row', gap: 10 },
  secondaryButton: { flex: 1, alignItems: 'center', padding: 13, borderRadius: 11, borderWidth: 1, borderColor: '#CAD4FF' },
  primaryButton: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 13, borderRadius: 11, backgroundColor: '#4868F5' },
  secondaryText: { color: '#4868F5', fontSize: 13, fontWeight: '700' },
  primaryText: { color: 'white', fontWeight: '800', fontSize: 13 },
  notice: { color: '#7944BC', backgroundColor: '#F4EEFE', padding: 12, borderRadius: 10, fontSize: 13 },
  empty: { textAlign: 'center', color: '#8791A5', marginTop: 30 },
});
