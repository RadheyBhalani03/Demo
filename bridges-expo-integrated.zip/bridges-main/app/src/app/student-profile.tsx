import { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ProfileAvatar } from '@/components/mentor-profile/profile-avatar';
import { SelectField } from '@/components/mentor-profile/select-field';
import { useAuth } from '@/hooks/use-auth';
import { useProfileQuery } from '@/services/profile/queries';
import { useCreateProfileMutation, useUpdateProfileMutation } from '@/services/profile/mutations';
import type { UserProfile } from '@/services/profile/types';

const BLUE = '#4868F5';
const SKILL_OPTIONS = [
  'React', 'Machine Learning', 'Python', 'Data Analysis', 'System Design',
  'TypeScript', 'Java', 'Product Management', 'UX Research', 'Finance', 'Public Speaking',
];
const INTEREST_OPTIONS = [
  'AI & ML', 'Startups', 'Open Source', 'Distributed Systems',
  'Career Growth', 'Design', 'Venture Capital', 'Research', 'Web3',
];
const MAJORS = [
  'Computer Science', 'Software Engineering', 'Information Technology',
  'Artificial Intelligence', 'Data Science', 'Electrical Engineering',
  'Mathematics', 'Business', 'Design', 'Other',
];

function FormField({ label, value, onChangeText, placeholder, multiline = false, maxLength }: {
  label: string; value: string; onChangeText: (value: string) => void;
  placeholder: string; multiline?: boolean; maxLength?: number;
}) {
  return (
    <View style={styles.fieldGroup}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        accessibilityLabel={label}
        style={[styles.input, multiline && styles.multiline]}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#A1A8B8"
        multiline={multiline}
        maxLength={maxLength}
        textAlignVertical={multiline ? 'top' : 'center'}
      />
      {maxLength ? <Text style={styles.counter}>{value.length}/{maxLength}</Text> : null}
    </View>
  );
}

function ChipGroup({ type, options, selected, onChange }: {
  type: 'skills' | 'interests'; options: string[]; selected: string[];
  onChange: (values: string[]) => void;
}) {
  const color = type === 'skills' ? BLUE : '#9B5CF5';
  return (
    <View style={styles.chips}>
      {options.map(label => {
        const active = selected.includes(label);
        return (
          <Pressable
            key={label}
            accessibilityRole="checkbox"
            accessibilityState={{ checked: active }}
            onPress={() => onChange(active ? selected.filter(t => t !== label) : [...selected, label])}
            style={[styles.chip, active && { borderColor: color, backgroundColor: type === 'skills' ? '#EDF2FF' : '#F6F0FF' }]}
          >
            <Text style={[styles.chipText, active && { color }]}>{active ? '✓ ' : ''}{label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export default function StudentProfileScreen() {
  const { data: profile, isLoading, isError, error, refetch } = useProfileQuery();
  if (isLoading) {
    return <View style={styles.center}><ActivityIndicator size="large" color={BLUE} /></View>;
  }
  if (isError) {
    return (
      <SafeAreaView style={styles.center}>
        <Text style={styles.heading}>Could not load your profile</Text>
        <Text style={styles.muted}>{error?.message ?? 'Please check your connection.'}</Text>
        <Pressable onPress={() => refetch()} style={styles.action}><Text style={styles.actionLabel}>Retry</Text></Pressable>
      </SafeAreaView>
    );
  }
  return <StudentProfileForm key={`${profile?.id ?? 'new'}-${profile?.updatedAt ?? ''}`} profile={profile} />;
}

function StudentProfileForm({ profile }: { profile?: UserProfile | null }) {
  const router = useRouter();
  const params = useLocalSearchParams<{ name?: string }>();
  const { user } = useAuth();
  const createProfile = useCreateProfileMutation();
  const updateProfile = useUpdateProfileMutation();
  const isNew = !profile;
  const [fullName, setFullName] = useState(profile?.displayName ?? user?.name ?? params.name ?? '');
  const [bio, setBio] = useState(profile?.bio ?? '');
  const [university, setUniversity] = useState(profile?.studentDetail?.university ?? '');
  const [year, setYear] = useState(profile?.studentDetail?.yearOfStudy ? `Year ${profile.studentDetail.yearOfStudy}` : 'Year 1');
  const [major, setMajor] = useState(profile?.studentDetail?.fieldOfStudy ?? 'Computer Science');
  const [skills, setSkills] = useState<string[]>(profile?.studentDetail?.skills ?? []);
  const [interests, setInterests] = useState<string[]>(profile?.studentDetail?.interests ?? []);
  const [linkedin, setLinkedin] = useState(profile?.studentDetail?.linkedinUrl ?? '');
  const [github, setGithub] = useState(profile?.studentDetail?.githubUrl ?? '');
  const [twitter, setTwitter] = useState(profile?.studentDetail?.twitterUrl ?? '');
  const saving = createProfile.isPending || updateProfile.isPending;

  async function finish() {
    if (fullName.trim().length < 2) {
      Alert.alert('Name required', 'Enter your full name (at least 2 characters).');
      return;
    }
    if (!university.trim()) {
      Alert.alert('University required', 'Enter your university to complete your profile.');
      return;
    }
    const payload = {
      displayName: fullName.trim(),
      role: 'STUDENT' as const,
      bio: bio.trim(),
      university: university.trim(),
      yearOfStudy: Number(year.replace('Year ', '')),
      degree: major,
      fieldOfStudy: major,
      skills,
      interests,
      linkedinUrl: linkedin.trim(),
      githubUrl: github.trim(),
      twitterUrl: twitter.trim(),
    };
    try {
      if (profile) {
        await updateProfile.mutateAsync({ id: profile.id, input: payload });
        router.replace('/(tabs)/profile');
      } else {
        if (!user?.id) {
          Alert.alert('Please sign in', 'You must sign in before saving your profile.');
          return;
        }
        await createProfile.mutateAsync({ ...payload, userId: user.id, email: user.email });
        router.replace('/(tabs)');
      }
    } catch (e: unknown) {
      Alert.alert('Could not save profile', e instanceof Error ? e.message : 'Please try again.');
    }
  }

  return (
    <SafeAreaView edges={['top', 'bottom']} style={styles.safe}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.header}>
          <View style={styles.headerRow}>
            <View style={styles.brandLogo}><Text style={styles.brandIcon}>♧</Text></View>
            <Text style={styles.brand}>Bridges</Text>
            <Text style={styles.step}>{isNew ? 'Step 3 of 3' : 'Edit profile'}</Text>
          </View>
          {isNew ? (
            <View style={styles.progress}>
              <View style={styles.progressPart} /><View style={styles.progressPart} /><View style={styles.progressPart} />
            </View>
          ) : null}
          <Text style={styles.heading}>{isNew ? 'Complete your profile' : 'Edit your profile'}</Text>
          <Text style={styles.muted}>This helps us match you with the right people.</Text>
        </View>

        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <ProfileAvatar uri={user?.avatarUri} />

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Basic Info</Text>
            <FormField label="Full Name" value={fullName} onChangeText={setFullName} placeholder="Jamie Chen" maxLength={50} />
            <FormField label="Bio" value={bio} onChangeText={setBio} placeholder="Share your ambitions and the mentorship you want..." multiline maxLength={200} />
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Academic</Text>
            <FormField label="University" value={university} onChangeText={setUniversity} placeholder="University of Adelaide" />
            <View style={styles.academicRow}>
              <SelectField label="Year" value={year} options={['Year 1', 'Year 2', 'Year 3', 'Year 4', 'Year 5']} onChange={setYear} style={{ flex: 1 }} />
              <SelectField label="Major" value={major} options={MAJORS} onChange={setMajor} style={{ flex: 1 }} />
            </View>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Skills</Text>
            <Text style={styles.cardHelp}>Tap to add or remove</Text>
            <ChipGroup type="skills" options={SKILL_OPTIONS} selected={skills} onChange={setSkills} />
          </View>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Interests</Text>
            <Text style={styles.cardHelp}>Choose what you want to explore</Text>
            <ChipGroup type="interests" options={INTEREST_OPTIONS} selected={interests} onChange={setInterests} />
          </View>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Social Links</Text>
            <FormField label="LinkedIn" value={linkedin} onChangeText={setLinkedin} placeholder="linkedin.com/in/yourname" />
            <FormField label="GitHub" value={github} onChangeText={setGithub} placeholder="github.com/yourname" />
            <FormField label="Twitter / X" value={twitter} onChangeText={setTwitter} placeholder="x.com/yourname" />
          </View>
        </ScrollView>
        <View style={styles.footer}>
          <Pressable
            accessibilityRole="button"
            disabled={saving}
            onPress={finish}
            style={[styles.action, saving && { opacity: 0.55 }]}
          >
            {saving ? <ActivityIndicator color="white" /> : <Text style={styles.actionLabel}>{isNew ? 'Finish Setup →' : 'Save Profile →'}</Text>}
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F6F7FA' },
  center: { flex: 1, backgroundColor: '#F6F7FA', alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 },
  header: { backgroundColor: 'white', paddingHorizontal: 25, paddingTop: 12, paddingBottom: 18 },
  headerRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  brandLogo: { backgroundColor: BLUE, borderRadius: 10, width: 29, height: 29, alignItems: 'center', justifyContent: 'center' },
  brandIcon: { color: 'white', fontSize: 19, fontWeight: '900' },
  brand: { marginLeft: 9, color: '#151B2C', fontSize: 14, fontWeight: '800' },
  step: { marginLeft: 'auto', color: '#A1AABD', fontSize: 11, fontWeight: '600' },
  progress: { flexDirection: 'row', gap: 5, marginBottom: 18 },
  progressPart: { flex: 1, height: 3, borderRadius: 6, backgroundColor: BLUE },
  heading: { fontSize: 20, fontWeight: '800', color: '#121A30', marginBottom: 6 },
  muted: { fontSize: 13, color: '#9098AB' },
  scroll: { flex: 1 },
  content: { padding: 18, paddingTop: 18, paddingBottom: 20 },
  card: { padding: 16, paddingVertical: 18, borderRadius: 17, backgroundColor: '#FFFFFF', marginBottom: 14, borderWidth: 1, borderColor: '#F0F1F4' },
  cardTitle: { color: '#141B30', fontSize: 14, fontWeight: '800', marginBottom: 14 },
  cardHelp: { color: '#A0A9BA', fontSize: 12, marginTop: -2, marginBottom: 15 },
  fieldGroup: { marginBottom: 12 },
  fieldLabel: { color: '#9CA4B4', fontSize: 10, textTransform: 'uppercase', fontWeight: '800', marginBottom: 7, letterSpacing: 0.3 },
  input: { backgroundColor: '#F7F8FB', borderWidth: 1, borderColor: '#ECEEF3', borderRadius: 11, color: '#222B42', fontSize: 13, minHeight: 43, paddingHorizontal: 13, paddingVertical: 11 },
  multiline: { minHeight: 85, lineHeight: 19 },
  counter: { textAlign: 'right', fontSize: 10, color: '#ADB5C8', marginTop: 5 },
  academicRow: { flexDirection: 'row', gap: 10, marginTop: 5 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  chip: { borderRadius: 20, borderWidth: 1, borderColor: '#EEF0F4', backgroundColor: '#F7F8FA', paddingVertical: 7, paddingHorizontal: 11 },
  chipText: { color: '#8992A5', fontSize: 12, fontWeight: '600' },
  footer: { backgroundColor: 'white', paddingHorizontal: 20, paddingVertical: 12, borderTopWidth: 1, borderTopColor: '#ECEEF3' },
  action: { backgroundColor: BLUE, borderRadius: 13, minHeight: 50, justifyContent: 'center', alignItems: 'center' },
  actionLabel: { color: 'white', fontWeight: '800', fontSize: 14 },
});
